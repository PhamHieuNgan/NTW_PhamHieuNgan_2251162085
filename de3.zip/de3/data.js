const initialData = [
    {
        "stt": 1,
        "ten": "Mai",
        "ho_dem": "Thục Anh",
        "dia_chi": "23 Hoàng Đạo Thúy, Thanh Xuân, Hà Nội",
        "hoat_dong": true
    },
    {
        "stt": 2,
        "ten": "Hoàng",
        "ho_dem": "Sĩn Hồng",
        "dia_chi": "23 Hoàng Đạo Thúy, Thanh Xuân, Hà Nội",
        "hoat_dong": false
    },
    {
        "stt": 3,
        "ten": "Tình",
        "ho_dem": "Mai Trung",
        "dia_chi": "1411 Đường Láng, Cầu Giấy, Hà Nội",
        "hoat_dong": true
    },
    {
        "stt": 4,
        "ten": "Hồng",
        "ho_dem": "Nguyễn Văn",
        "dia_chi": "1411 Đường Láng, Cầu Giấy, Hà Nội",
        "hoat_dong": false
    }
];