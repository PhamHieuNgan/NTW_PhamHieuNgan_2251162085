$(document).ready(function() {
    let employees = initialData;
    let sttCounter = employees.length + 1;

    function renderTable() {
        const tableBody = $('#employee-table-body');
        tableBody.empty(); 

        employees.forEach(function(employee) {
            const row = `
                <tr>
                    <td class="text-center"><input class="form-check-input" type="checkbox"></td>
                    <td>
                        <button class="btn btn-sm btn-primary"><i class="bi bi-eye"></i></button>
                        <button class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i></button>
                        <button class="btn btn-sm btn-danger"><i class="bi bi-trash"></i></button>
                    </td>
                    <td>${employee.stt}</td>
                    <td>${employee.ten}</td>
                    <td>${employee.ho_dem}</td>
                    <td>${employee.dia_chi}</td>
                    <td class="text-center">
                        ${employee.hoat_dong ? '<span class="text-success">✔</span>' : '<span class="text-danger">✖</span>'}
                    </td>
                </tr>
            `;
            tableBody.append(row);
        });
    }

    function clearError(input) {
        input.removeClass('is-invalid');
        input.next('.invalid-feedback').text('');
    }

    function showError(input, message) {
        input.addClass('is-invalid');
        input.next('.invalid-feedback').text(message);
    }

    $('#addEmployeeBtn').on('click', function() {
        const firstNameInput = $('#firstName');
        const lastNameInput = $('#lastName');
        const addressInput = $('#address');

        const firstName = firstNameInput.val().trim();
        const lastName = lastNameInput.val().trim();
        const address = addressInput.val().trim();

        let isValid = true;

        clearError(firstNameInput);
        clearError(lastNameInput);
        clearError(addressInput);

        if (firstName === '') {
            showError(firstNameInput, 'Tên không được bỏ trống.');
            isValid = false;
        } else if (firstName.length > 15) {
            showError(firstNameInput, 'Tên không quá 15 ký tự.');
            isValid = false;
        }

        if (lastName === '') {
            showError(lastNameInput, 'Họ đệm không được bỏ trống.');
            isValid = false;
        } else if (lastName.length > 20) {
            showError(lastNameInput, 'Họ đệm không quá 20 ký tự.');
            isValid = false;
        }

        if (address === '') {
            showError(addressInput, 'Địa chỉ không được bỏ trống.');
            isValid = false;
        } else if (address.length > 50) {
            showError(addressInput, 'Địa chỉ không quá 50 ký tự.');
            isValid = false;
        }

        if (isValid) {
            const newEmployee = {
                "stt": sttCounter++,
                "ten": firstName,
                "ho_dem": lastName,
                "dia_chi": address,
                "hoat_dong": true 
            };

            employees.push(newEmployee);
            renderTable();

            $('#addEmployeeModal').modal('hide');
            $('#addEmployeeForm')[0].reset();
            clearError(firstNameInput);
            clearError(lastNameInput);
            clearError(addressInput);
        }
    });
    
    $('#addEmployeeModal').on('hidden.bs.modal', function () {
        $('#addEmployeeForm')[0].reset();
        clearError($('#firstName'));
        clearError($('#lastName'));
        clearError($('#address'));
    });

    renderTable();
});