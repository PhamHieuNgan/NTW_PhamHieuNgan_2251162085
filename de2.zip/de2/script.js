// script.js
document.addEventListener('DOMContentLoaded', function() {
  const tableBody = document.getElementById('transaction-table-body');
  const addTransactionForm = document.getElementById('addTransactionForm');
  const submitBtn = document.getElementById('submitBtn');
  const addModal = new bootstrap.Modal(document.getElementById('addTransactionModal'));

  // Hàm để render dữ liệu ra bảng
  function renderTable() {
    tableBody.innerHTML = ''; // Xóa dữ liệu cũ
    transactions.forEach(tx => {
      const row = `
        <tr>
          <td><input type="checkbox" class="form-check-input"></td>
          <td>
            <button class="btn btn-sm btn-info"><i class="fa fa-eye"></i></button>
            <button class="btn btn-sm btn-warning"><i class="fa fa-pencil"></i></button>
            <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
          </td>
          <td>${tx.id}</td>
          <td>${tx.customer}</td>
          <td>${tx.employee}</td>
          <td>${tx.amount}</td>
          <td>${tx.date}</td>
        </tr>
      `;
      tableBody.innerHTML += row;
    });
  }

  // Hàm xóa thông báo lỗi
  function clearErrors() {
      document.getElementById('customerNameError').textContent = '';
      document.getElementById('employeeNameError').textContent = '';
      document.getElementById('amountError').textContent = '';
  }

  // Hàm xử lý việc thêm giao dịch
  submitBtn.addEventListener('click', function() {
    clearErrors(); // Xóa lỗi cũ trước khi kiểm tra

    const customerNameInput = document.getElementById('customerName');
    const employeeNameInput = document.getElementById('employeeName');
    const amountInput = document.getElementById('amount');

    let isValid = true;

    // --- Bắt đầu phần kiểm tra dữ liệu (validation) ---
    // 1. Kiểm tra trường "Khách hàng"
    if (customerNameInput.value.trim() === '') {
      document.getElementById('customerNameError').textContent = 'Tên khách hàng không được để trống.';
      isValid = false;
    } else if (customerNameInput.value.length > 30) {
      document.getElementById('customerNameError').textContent = 'Tên khách hàng không được quá 30 ký tự.';
      isValid = false;
    }

    // 2. Kiểm tra trường "Nhân viên"
    if (employeeNameInput.value.trim() === '') {
      document.getElementById('employeeNameError').textContent = 'Tên nhân viên không được để trống.';
      isValid = false;
    } else if (employeeNameInput.value.length > 30) {
      document.getElementById('employeeNameError').textContent = 'Tên nhân viên không được quá 30 ký tự.';
      isValid = false;
    }

    // 3. Kiểm tra trường "Số tiền"
    if (amountInput.value.trim() === '') {
      document.getElementById('amountError').textContent = 'Số tiền không được để trống.';
      isValid = false;
    }
    // --- Kết thúc phần kiểm tra dữ liệu ---

    if (isValid) {
      const newId = Math.max(...transactions.map(t => t.id)) + 1; // Tạo ID mới
      const newTransaction = {
        id: newId,
        customer: customerNameInput.value,
        employee: employeeNameInput.value,
        amount: amountInput.value,
        date: new Date().toLocaleString('vi-VN') // Lấy ngày giờ hiện tại
      };

      transactions.unshift(newTransaction); // Thêm vào đầu mảng
      renderTable(); // Cập nhật lại bảng
      addTransactionForm.reset(); // Reset form
      addModal.hide(); // Đóng modal
    }
  });

  // Xóa thông báo lỗi khi người dùng bắt đầu nhập liệu
  document.getElementById('addTransactionModal').addEventListener('hidden.bs.modal', function () {
    clearErrors();
    addTransactionForm.reset();
  });


  // Render bảng lần đầu khi trang được tải
  renderTable();
});