$(document).ready(function() {

    function renderTable() {
        const tableBody = $('#employee-table-body');
        tableBody.empty(); 

        employees.forEach(employee => {
            const rowHtml = `
                <tr>
                    <td><input type="checkbox"></td>
                    <td>${employee.name}</td>
                    <td>${employee.email}</td>
                    <td>${employee.address}</td>
                    <td>${employee.phone}</td>
                    <td>
                        <a href="#" class="edit"><i class="fas fa-pencil-alt text-warning"></i></a>
                        <a href="#" class="delete"><i class="fas fa-trash-alt text-danger"></i></a>
                    </td>
                </tr>
            `;
            tableBody.append(rowHtml); 
        });

        $('#showing-entries').text(employees.length);
        $('#total-entries').text(employees.length);
    }

    $('#add-employee-form').on('submit', function(event) {
        event.preventDefault(); 

        $('.error-message').text('');
        let isValid = true;

        const name = $('#add-name').val().trim();
        const email = $('#add-email').val().trim();
        const address = $('#add-address').val().trim();
        const phone = $('#add-phone').val().trim();

        if (name === '') {
            $('#add-name').next('.error-message').text('Phản hồi: Tên không được bỏ trống.');
            isValid = false;
        }
        if (email === '') {
            $('#add-email').next('.error-message').text('Phản hồi: Email không được bỏ trống.');
            isValid = false;
        }
        if (address === '') {
            $('#add-address').next('.error-message').text('Phản hồi: Địa chỉ không được bỏ trống.');
            isValid = false;
        }
        
        if (phone === '') {
            $('#add-phone').next('.error-message').text('Phản hồi: Số điện thoại không được bỏ trống.');
            isValid = false;
        } else {
            const phoneRegex = /^0\d{9}$/; 
            if (!phoneRegex.test(phone)) {
                $('#add-phone').next('.error-message').text('Phản hồi: Số điện thoại phải có 10 ký tự và bắt đầu bằng số 0.');
                isValid = false;
            }
        }

        if (isValid) {
            const newEmployee = {
                id: employees.length > 0 ? Math.max(...employees.map(e => e.id)) + 1 : 1,
                name: name,
                email: email,
                address: address,
                phone: phone
            };

            employees.push(newEmployee); 
            renderTable(); 

            $('#add-employee-form')[0].reset(); 
            $('#addEmployeeModal').modal('hide'); 
        }
    });

    renderTable();
});